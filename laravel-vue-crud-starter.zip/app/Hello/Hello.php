<?php
namespace App\Hello;

class Hello {
    public function hello(){
        return "test hello";
    }
    
}