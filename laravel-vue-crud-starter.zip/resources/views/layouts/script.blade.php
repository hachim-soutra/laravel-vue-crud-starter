<script src="{{ asset('libs/jquery/jquery/dist/jquery.js') }}"></script>
<script src="{{ asset('libs/jquery/tether/dist/js/tether.min.js') }}"></script>
<script src="{{ asset('libs/jquery/bootstrap/dist/js/bootstrap.js') }}"></script>
<script src="{{ asset('libs/jquery/underscore/underscore-min.js') }}"></script>
<script src="{{ asset('libs/jquery/jQuery-Storage-API/jquery.storageapi.min.js') }}"></script>

<script src="{{ asset('scripts/config.lazyload.js') }}"></script>

<script src="{{ asset('scripts/ui-jp.js') }}"></script>
<script src="{{ asset('scripts/ui-include.js') }}"></script>



<script src="{{ asset('scripts/app.js') }}"></script>
