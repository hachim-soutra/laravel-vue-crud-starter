<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
    <div id="app" style="width: 80%;margin: 0 0 0 5%;
    height: 80vh;
    min-height: 70vh;
    overflow-y: scroll;
">
        <?php echo $__env->make('layouts.aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('layouts.content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <router-view></router-view>

        <vue-progress-bar></vue-progress-bar>

    </div>
    <?php echo $__env->make('layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="<?php echo e(mix('/js/app.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\Users\hp\Documents\laravel\laravel-vue-crud-starter\resources\views/layouts/master.blade.php ENDPATH**/ ?>