<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\Original Shop\Documents\GitHub\backend\laravel-vue-crud-starter\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>