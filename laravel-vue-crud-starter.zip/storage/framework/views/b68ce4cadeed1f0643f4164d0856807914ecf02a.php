<script src="<?php echo e(asset('libs/jquery/jquery/dist/jquery.js')); ?>"></script>
<script src="<?php echo e(asset('libs/jquery/tether/dist/js/tether.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/jquery/bootstrap/dist/js/bootstrap.js')); ?>"></script>
<script src="<?php echo e(asset('libs/jquery/underscore/underscore-min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/jquery/jQuery-Storage-API/jquery.storageapi.min.js')); ?>"></script>

<script src="<?php echo e(asset('scripts/config.lazyload.js')); ?>"></script>

<script src="<?php echo e(asset('scripts/ui-jp.js')); ?>"></script>
<script src="<?php echo e(asset('scripts/ui-include.js')); ?>"></script>



<script src="<?php echo e(asset('scripts/app.js')); ?>"></script>
<?php /**PATH C:\Users\Original Shop\Documents\GitHub\backend\laravel-vue-crud-starter\resources\views/layouts/script.blade.php ENDPATH**/ ?>