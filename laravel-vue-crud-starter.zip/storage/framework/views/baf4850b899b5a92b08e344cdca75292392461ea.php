<?php echo e($slot); ?>

<?php /**PATH C:\Users\hp\Documents\laravel\laravel-vue-crud-starter\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>