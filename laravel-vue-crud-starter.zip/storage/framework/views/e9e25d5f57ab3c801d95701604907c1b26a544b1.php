<?php echo e($slot); ?>

<?php /**PATH C:\Users\Original Shop\Documents\GitHub\backend\laravel-vue-crud-starter\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>