<?php $__env->startSection('content'); ?>

<!-- ############ LAYOUT START-->
    <div class="center-block w-xxl w-auto-xs p-y-md h-100">
        <div class="p-a-md box-color r box-shadow-z1 text-color m-a">
            <div class="m-b text-sm">
                <!-- Sign in with your Flatkit Account -->
                <?php echo e(__('Login')); ?>

            </div>
            <form  method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>
                <div class="md-form-group float-label">
                    <input name="email" type="email" class="md-input <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus >
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label><?php echo e(__('E-Mail Address')); ?></label>
                </div>
                <div class="md-form-group float-label">
                    <input type="password" class="md-input  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label>Password</label>

                </div>
                <div class="m-b-md">
                    <label class="md-check">
                        <input type="checkbox"><i class="primary"></i>  <?php echo e(__('Remember Me')); ?>

                    </label>
                </div>
                <button type="submit" class="btn primary btn-block p-x-md"><?php echo e(__('Login')); ?></button>
            </form>
        </div>

        <div class="p-v-lg text-center">
            <div class="m-b">
                <a href="<?php echo e(route('password.request')); ?>" class="text-primary _600"><?php echo e(__('Forgot Your Password?')); ?></a>
            </div>
            <div><?php echo e(__('Do not have an account?')); ?>

                <a  class="text-primary _600" href="<?php echo e(route('register')); ?>">
                    <?php echo e(__('Register')); ?>

                </a>
            </div>
        </div>
    </div>

<!-- ############ LAYOUT END-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp\Documents\laravel\laravel-vue-crud-starter\resources\views/auth/login.blade.php ENDPATH**/ ?>